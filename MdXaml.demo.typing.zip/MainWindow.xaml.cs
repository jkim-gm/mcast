using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MdXaml.Demo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (DataContext is MainWindowViewModel vm)
            {
                vm.Documents.CollectionChanged += (_, __) => ScrollToEndIfAtBottom();
                vm.DocumentsFlow.CollectionChanged += (_, __) => ScrollToEndIfAtBottom();
                vm.DocumentsIncremental.CollectionChanged += (_, __) => ScrollToEndIfAtBottom();
                // Fires while typing is in progress so the view keeps following new content,
                // but only if the user hasn't scrolled away to read something else.
                vm.ContentUpdated += (_, __) => ScrollToEndIfAtBottom();
            }
        }

        // Only follows new content when the user is already at (or very near) the bottom,
        // so scrolling up to re-read earlier messages isn't fought by the typing effect.
        private void ScrollToEndIfAtBottom()
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                try
                {
                    if (MessagesScrollViewer == null) return;

                    const double bottomThreshold = 40;
                    bool atBottom = MessagesScrollViewer.VerticalOffset >=
                                     MessagesScrollViewer.ScrollableHeight - bottomThreshold;

                    if (atBottom)
                        MessagesScrollViewer.ScrollToEnd();
                }
                catch { }
            }));
        }
    }
}
