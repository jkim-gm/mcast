using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Markup;

namespace MdXaml.Demo
{
    public enum TypingMode
    {
        Char,
        Word,
        Flow
    }

    /// <summary>
    /// Mutable message wrapper. Typing effects update <see cref="Text"/> in place so the
    /// containing ObservableCollection only raises Add (not Replace) and the bound
    /// MarkdownScrollViewer container is not regenerated on every keystroke.
    /// </summary>
    public class TypedMessage : System.ComponentModel.INotifyPropertyChanged
    {
        private string _text = string.Empty;
        public string Text
        {
            get => _text;
            set
            {
                if (_text == value) return;
                _text = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Text)));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }

    /// <summary>
    /// Mutable Flow-mode message wrapper, mirroring <see cref="TypedMessage"/>: the
    /// FlowDocumentScrollViewer binds to <see cref="Document"/> so updates swap the
    /// bound value in place instead of replacing the item in the ObservableCollection.
    /// </summary>
    public class FlowMessage : System.ComponentModel.INotifyPropertyChanged
    {
        private FlowDocument _document = new FlowDocument();
        public FlowDocument Document
        {
            get => _document;
            set
            {
                if (_document == value) return;
                _document = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Document)));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }

    // Lets StartTypingChar/StartTypingWord queue updates without caring whether
    // UseIncrementalAppend is on - the loop body stays the same either way.
    internal interface ITypingSink
    {
        void QueueUpdate(string text);
        void ApplyFinal(string text);
    }

    // The default path: unchanged from before UseIncrementalAppend existed - coalesced
    // updates just set TypedMessage.Text, and MarkdownScrollViewer does a full Transform().
    internal sealed class PlainTypingSink : ITypingSink
    {
        private readonly System.Collections.Concurrent.ConcurrentDictionary<object, Action> _pendingUpdates;
        private readonly TypedMessage _message;

        public PlainTypingSink(System.Collections.Concurrent.ConcurrentDictionary<object, Action> pendingUpdates, TypedMessage message)
        {
            _pendingUpdates = pendingUpdates;
            _message = message;
        }

        public void QueueUpdate(string text) => _pendingUpdates[_message] = () => _message.Text = text;

        public void ApplyFinal(string text) => Application.Current.Dispatcher.BeginInvoke(new Action(() =>
        {
            _pendingUpdates.TryRemove(_message, out _);
            _message.Text = text;
        }));
    }

    // The opt-in path: coalesced updates go through Markdown.TransformAppend() on a
    // per-message engine instead of a full Transform() of the whole accumulated text.
    internal sealed class IncrementalTypingSink : ITypingSink
    {
        private readonly System.Collections.Concurrent.ConcurrentDictionary<object, Action> _pendingUpdates;
        private readonly FlowMessage _message;
        private readonly Markdown _engine;

        public IncrementalTypingSink(System.Collections.Concurrent.ConcurrentDictionary<object, Action> pendingUpdates, FlowMessage message, Markdown engine)
        {
            _pendingUpdates = pendingUpdates;
            _message = message;
            _engine = engine;
        }

        public void QueueUpdate(string text) => _pendingUpdates[_message] = () => _message.Document = _engine.TransformAppend(text);

        public void ApplyFinal(string text) => Application.Current.Dispatcher.BeginInvoke(new Action(() =>
        {
            _pendingUpdates.TryRemove(_message, out _);
            _message.Document = _engine.TransformAppend(text);
        }));
    }

public class MainWindowViewModel : System.ComponentModel.INotifyPropertyChanged
    {
        public System.Collections.ObjectModel.ObservableCollection<TypedMessage> Documents { get; }
        public System.Collections.ObjectModel.ObservableCollection<FlowDocument> DocumentsFlow { get; }
        // Rendered via a FlowDocumentScrollViewer, like DocumentsFlow, but populated by
        // Char/Word typing through Markdown.TransformAppend() instead of a full Transform()
        // per update - see UseIncrementalAppend.
        public System.Collections.ObjectModel.ObservableCollection<FlowMessage> DocumentsIncremental { get; }
        public System.Windows.Input.ICommand AddCommand { get; }
        public System.Windows.Input.ICommand CancelCommand { get; }
        public System.Windows.Input.ICommand PauseCommand { get; }
        private TypingMode _selectedTypingMode;
        public TypingMode SelectedTypingMode
        {
            get => _selectedTypingMode;
            set
            {
                if (_selectedTypingMode == value) return;
                _selectedTypingMode = value;
                FirePropertyChanged();
                FirePropertyChanged(nameof(IsStringMode));
                FirePropertyChanged(nameof(IsFlowMode));
                FirePropertyChanged(nameof(StringModeVisibility));
                FirePropertyChanged(nameof(IncrementalModeVisibility));
                FirePropertyChanged(nameof(FlowModeVisibility));
            }
        }
        public bool IsStringMode => SelectedTypingMode != TypingMode.Flow;
        public bool IsFlowMode => SelectedTypingMode == TypingMode.Flow;
        public List<TypingMode> TypingModes { get; }

        // When on, Char/Word modes render through Markdown.TransformAppend() (one FlowMessage
        // per message, updated in place) instead of the default full-Transform()-per-update
        // path via TypedMessage.Text + MarkdownScrollViewer. Only affects Char/Word; Flow mode
        // is unaffected either way. The default path is left entirely as it was so both remain
        // available side by side.
        private bool _useIncrementalAppend;
        public bool UseIncrementalAppend
        {
            get => _useIncrementalAppend;
            set
            {
                if (_useIncrementalAppend == value) return;
                _useIncrementalAppend = value;
                FirePropertyChanged();
                FirePropertyChanged(nameof(StringModeVisibility));
                FirePropertyChanged(nameof(IncrementalModeVisibility));
            }
        }
        public Visibility StringModeVisibility => IsStringMode && !UseIncrementalAppend ? Visibility.Visible : Visibility.Collapsed;
        public Visibility IncrementalModeVisibility => IsStringMode && UseIncrementalAppend ? Visibility.Visible : Visibility.Collapsed;
        public Visibility FlowModeVisibility => IsFlowMode ? Visibility.Visible : Visibility.Collapsed;
        public int CharDelay { get; set; }
        public int WordDelay { get; set; }
        public int ChunkDelay { get; set; }
        public bool PunctuationAware { get; set; }
        public double SpeedMultiplier { get; set; }

        private System.Threading.CancellationTokenSource _typingCts;
        private System.Threading.ManualResetEventSlim _pauseEvent = new System.Threading.ManualResetEventSlim(true);
        private bool _isPaused;
        public bool IsPaused
        {
            get => _isPaused;
            private set
            {
                if (_isPaused == value) return;
                _isPaused = value;
                FirePropertyChanged();
            }
        }

        public MainWindowViewModel()
        {
            Styles = new List<StyleInfo>
            {
                new StyleInfo("Plain", null),
                new StyleInfo("Standard", MarkdownStyle.Standard),
                new StyleInfo("Compact", MarkdownStyle.Compact),
                new StyleInfo("GithubLike", MarkdownStyle.GithubLike),
                new StyleInfo("Sasabune", MarkdownStyle.Sasabune),
                new StyleInfo("SasabuneStandard", MarkdownStyle.SasabuneStandard),
                new StyleInfo("SasabuneCompact", MarkdownStyle.SasabuneCompact)
            };

            SelectedStyleInfo = Styles[2];

            var subjectType = typeof(MainWindow);
            var subjectAssembly = GetType().Assembly;
            using (Stream stream = subjectAssembly.GetManifestResourceStream(subjectType.FullName + ".md"))
            {
                string ragText;
                if (stream == null)
                {
                    ragText = String.Format("Could not find sample text *{0}*.md", subjectType.FullName);
                }
                else
                {
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        ragText = reader.ReadToEnd();
                    }
                }
                _rawText = ragText;
            }

			 // initialize documents collection and add command for chat-like behavior
			Documents = new System.Collections.ObjectModel.ObservableCollection<TypedMessage> { new TypedMessage { Text = _rawText } };
            DocumentsFlow = new System.Collections.ObjectModel.ObservableCollection<FlowDocument>();
            DocumentsIncremental = new System.Collections.ObjectModel.ObservableCollection<FlowMessage>();
            SelectedTypingMode = TypingMode.Word;
            TypingModes = Enum.GetValues(typeof(TypingMode)).Cast<TypingMode>().ToList();
            // default delays (ms)
            CharDelay = 5;
            WordDelay = 5;
            ChunkDelay = 200;
            SpeedMultiplier = 1.0;
            PunctuationAware = true;

            // Load MainWindow.md on demand and start typing to avoid startup I/O.
            // Disabled while a typing effect is already running so repeated clicks
            // cannot cancel an in-flight message before it finishes.
            AddCommand = new DelegateCommand(async () => await LoadMainWindowMdAndStartTypingAsync(), () => !IsTyping);

            // Initialize pending update flusher to coalesce frequent typing updates. Keyed
            // by the message object (identity), valued by a closure that applies the latest
            // update - shared by both the plain (TypedMessage.Text) and incremental
            // (FlowMessage.Document via TransformAppend) typing paths.
            _pendingUpdates = new System.Collections.Concurrent.ConcurrentDictionary<object, Action>();
            _flushTimer = new System.Windows.Threading.DispatcherTimer(
                TimeSpan.FromMilliseconds(50),
                System.Windows.Threading.DispatcherPriority.Background,
                (s, e) =>
                {
                    bool any = false;
                    foreach (var kv in _pendingUpdates.ToArray())
                    {
                        kv.Value();
                        _pendingUpdates.TryRemove(kv.Key, out _);
                        any = true;
                    }
                    if (any) RaiseContentUpdated();
                },
                System.Windows.Application.Current.Dispatcher);
            _flushTimer.Start();
            CancelCommand = new DelegateCommand(() => CancelTyping());
            PauseCommand = new DelegateCommand(() => TogglePause());

            _activeTabIndex = 0;

            ForegroundRed = 0x00;
            ForegroundGreen = 0x00;
            ForegroundBlue = 0x00;

            BackgroundRed = 0xFF;
            BackgroundGreen = 0xFF;
            BackgroundBlue = 0xFF;
        }

        #region Style & Colors

        public StyleInfo _selectedStyleInfo;
        public StyleInfo SelectedStyleInfo
        {
            get { return _selectedStyleInfo; }
            set
            {
                if (_selectedStyleInfo == value) return;
                _selectedStyleInfo = value;
                FirePropertyChanged();
            }
        }

        public List<StyleInfo> _styles;
        public List<StyleInfo> Styles
        {
            get { return _styles; }
            set
            {
                if (_styles == value) return;
                _styles = value;
                FirePropertyChanged();
            }
        }

        private byte _ForegroundRed;
        public byte ForegroundRed
        {
            get => _ForegroundRed;
            set
            {
                if (_ForegroundRed == value) return;
                _ForegroundRed = value;
                FirePropertyChanged();
            }
        }

        private byte _ForegroundGreen;
        public byte ForegroundGreen
        {
            get => _ForegroundGreen;
            set
            {
                if (_ForegroundGreen == value) return;
                _ForegroundGreen = value;
                FirePropertyChanged();
            }
        }

        private byte _ForegroundBlue;
        public byte ForegroundBlue
        {
            get => _ForegroundBlue;
            set
            {
                if (_ForegroundBlue == value) return;
                _ForegroundBlue = value;
                FirePropertyChanged();
            }
        }

        private byte _BackgroundRed;
        public byte BackgroundRed
        {
            get => _BackgroundRed;
            set
            {
                if (_BackgroundRed == value) return;
                _BackgroundRed = value;
                FirePropertyChanged();
            }
        }

        private byte _BackgroundGreen;
        public byte BackgroundGreen
        {
            get => _BackgroundGreen;
            set
            {
                if (_BackgroundGreen == value) return;
                _BackgroundGreen = value;
                FirePropertyChanged();
            }
        }

        private byte _BackgroundBlue;
        public byte BackgroundBlue
        {
            get => _BackgroundBlue;
            set
            {
                if (_BackgroundBlue == value) return;
                _BackgroundBlue = value;
                FirePropertyChanged();
            }
        }

        #endregion


        #region Markdown Text

        private Task _textXamlChangeEvent;
        private string _rawText;
        public string RawText
        {
            get => _rawText ?? string.Empty;
            set
            {
                if (_rawText == value) return;
                _rawText = value;
                if (_textXamlChangeEvent == null || _textXamlChangeEvent.Status >= TaskStatus.RanToCompletion)
                {
                    _textXamlChangeEvent = Task.Run(() =>
                    {
                        Task.Delay(100);
                    retry:
                        var oldVal = _rawText;
                        Thread.MemoryBarrier();
                        FirePropertyChanged(nameof(RawText));
                        Thread.MemoryBarrier();
                        if (oldVal != _rawText) goto retry;
                    });
                }
            }
        }

        private FlowDocument _renderingDocument;
        public FlowDocument RenderingDocument
        {
            get => _renderingDocument;
            set
            {
                if (_renderingDocument == value) return;
                _renderingDocument = value;
                FirePropertyChanged();
                RefreshVisibleOutput();
            }
        }

        private FlowDocument _requestingConvertXaml;
        public FlowDocument RequestingConvertXaml
        {
            get => _requestingConvertXaml;
            set
            {
                if (_requestingConvertXaml == value) return;
                _requestingConvertXaml = value;
                FirePropertyChanged();
            }
        }

        private FlowDocument _requestingConvertMatter;
        public FlowDocument RequestingConvertMatter
        {
            get => _requestingConvertMatter;
            set
            {
                if (_requestingConvertMatter == value) return;
                _requestingConvertMatter = value;
                FirePropertyChanged();
            }
        }


        #endregion

        private int _activeTabIndex;
        public int ActiveTabIndex
        {
            get => _activeTabIndex;
            set
            {
                if (_activeTabIndex == value) return;
                _activeTabIndex = value;
                FirePropertyChanged();
                RefreshVisibleOutput();
            }
        }

        private void RefreshVisibleOutput()
        {
            switch (_activeTabIndex)
            {
                case 1:
                    RequestingConvertXaml = RenderingDocument;
                    break;
                case 2:
                    RequestingConvertMatter = RenderingDocument;
                    break;
            }
        }


        /// <summary> <see cref="INotifyPropertyChanged"/> </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// <see cref="INotifyPropertyChanged"/>のイベント発火用
        /// </summary>
        /// <param name="propertyName"></param>
        protected void FirePropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null && propertyName != null)
            {
                var e = new PropertyChangedEventArgs(propertyName);
                PropertyChanged(this, e);
            }
        }

        // Keep an async void wrapper for existing callers (event handlers) while
        // providing an awaitable implementation StartTypingAsync.
        static MainWindowViewModel()
        {
            // Forward mouse wheel from inner MarkdownScrollViewer to outer ScrollViewer
            System.Windows.EventManager.RegisterClassHandler(typeof(MdXaml.MarkdownScrollViewer),
                System.Windows.UIElement.PreviewMouseWheelEvent,
                new System.Windows.Input.MouseWheelEventHandler(OnMarkdownPreviewMouseWheel),
                true);
        }

        private static void OnMarkdownPreviewMouseWheel(object sender, System.Windows.Input.MouseWheelEventArgs e)
        {
            if (e.Handled) return;

            // Walk up the visual tree to find an outer ScrollViewer to scroll
            var parent = System.Windows.Media.VisualTreeHelper.GetParent((System.Windows.DependencyObject)sender);
            while (parent != null && !(parent is System.Windows.Controls.ScrollViewer))
            {
                parent = System.Windows.Media.VisualTreeHelper.GetParent(parent);
            }

            if (parent is System.Windows.Controls.ScrollViewer sv)
            {
                var args = new System.Windows.Input.MouseWheelEventArgs(e.MouseDevice, e.Timestamp, e.Delta)
                {
                    RoutedEvent = System.Windows.UIElement.MouseWheelEvent,
                    Source = sender
                };
                sv.RaiseEvent(args);
                e.Handled = true;
            }
        }

        // pending updates for coalescing frequent UI writes from typing
        private System.Collections.Concurrent.ConcurrentDictionary<object, Action> _pendingUpdates;
        private System.Windows.Threading.DispatcherTimer _flushTimer;

        // Raised whenever typed content changes (throttled), so the view can decide
        // whether to auto-scroll (e.g. only if the user is already at the bottom).
        public event EventHandler ContentUpdated;
        private void RaiseContentUpdated() => ContentUpdated?.Invoke(this, EventArgs.Empty);

        // True while a typing effect is actively running. Used to disable the Add
        // button so a repeated click cannot cancel an in-flight message.
        private bool _isTyping;
        public bool IsTyping
        {
            get => _isTyping;
            private set
            {
                if (_isTyping == value) return;
                _isTyping = value;
                FirePropertyChanged();
                System.Windows.Input.CommandManager.InvalidateRequerySuggested();
            }
        }

        // How many characters max for a "short" word to be grouped during Word typing mode.
        // Default is 10 but can be changed by the user at runtime.
        private int _shortWordGroupThreshold = 10;
        public int ShortWordGroupThreshold
        {
            get => _shortWordGroupThreshold;
            set
            {
                var v = Math.Max(1, value);
                if (_shortWordGroupThreshold == v) return;
                _shortWordGroupThreshold = v;
                FirePropertyChanged();
            }
        }

        // Typing style option. Default is Compact.
        public enum TypingStyleOption { Compact, Standard }
        private TypingStyleOption _typingStyle = TypingStyleOption.Compact;
        public TypingStyleOption TypingStyle
        {
            get => _typingStyle;
            set
            {
                if (_typingStyle == value) return;
                _typingStyle = value;
                FirePropertyChanged();
            }
        }

        // Expose enum values for easy binding in XAML
        public Array TypingStyleOptions => Enum.GetValues(typeof(TypingStyleOption));

        // How much longer to pause after sentence-ending punctuation when
        // PunctuationAware is enabled. Shared by char and word typing modes.
        private const int PunctuationPauseMultiplier = 3;

        private void StartTyping(string source)
        {
            // Run typing on a background thread to avoid impacting UI responsiveness
            _ = System.Threading.Tasks.Task.Run(async () => await StartTypingAsync(source));
        }

        private async Task StartTypingAsync(string source)
        {
            // Enforce fast defaults so typing remains speedy
            try
            {
                // If delays are uninitialized or too small, set sensible fast defaults
                if (WordDelay < 1) WordDelay = 1;
                if (CharDelay < 1) CharDelay = 1;
            }
            catch
            {
                // ignore if properties not accessible; best-effort only
            }

            switch (SelectedTypingMode)
            {
                case TypingMode.Char:
                    await StartTypingChar(source);
                    break;
                case TypingMode.Word:
                    await StartTypingWord(source);
                    break;
                case TypingMode.Flow:
                    await StartTypingFlow(source);
                    break;
            }
        }

        // Starts typing out the demo markdown that was already loaded into _rawText at
        // startup (from the embedded MainWindow.md resource - see the constructor).
        //
        // This used to re-read "MainWindow.md" from disk on every click via a retry/sharing
        // FileStream helper, but the path it actually used was the *embedded resource name*
        // (typeof(MainWindow).FullName + ".md" = "MdXaml.Demo.MainWindow.md"), not a real
        // filesystem path - the physical file is just "MainWindow.md" and is never copied to
        // the output directory (<CopyToOutputDirectory>Never</CopyToOutputDirectory>). So the
        // read always threw FileNotFoundException, and every click silently did nothing.
        // Flow mode made this obvious because DocumentsFlow starts empty; Char/Word masked
        // it because Documents already has the same content pre-seeded at startup.
        public async System.Threading.Tasks.Task LoadMainWindowMdAndStartTypingAsync()
        {
            if (string.IsNullOrEmpty(_rawText)) return;
            await StartTypingAsync(_rawText);
        }

        private async Task StartTypingChar(string source)
        {
            if (string.IsNullOrEmpty(source)) return;

            CancelExistingAndPrepare();

            // Capture the current CTS token locally to avoid races with cancel/prepare.
            var token = _typingCts?.Token ?? System.Threading.CancellationToken.None;

            try
            {
                var sink = CreateTypingSink();
                var sb = new StringBuilder();

                foreach (char c in source)
                {
                    _pauseEvent.Wait();
                    token.ThrowIfCancellationRequested();

                    sb.Append(c);

                    // Coalesce frequent updates; the flush timer applies the latest text
                    // to the message in place, so no collection Replace is triggered.
                    sink.QueueUpdate(sb.ToString());

                    int delay = (int)(CharDelay / SpeedMultiplier);
                    if (PunctuationAware && (c == '.' || c == '!' || c == '?')) delay = (int)(delay * PunctuationPauseMultiplier);
                    await Task.Delay(Math.Max(1, delay), token);
                }

                // Apply the final text immediately rather than waiting for the next flush tick.
                sink.ApplyFinal(sb.ToString());
            }
            catch (OperationCanceledException)
            {
                // Cancellation requested - stop typing silently.
            }
            finally
            {
                ClearTypingToken();
            }
        }

        // Creates the right ITypingSink for the current UseIncrementalAppend setting and
        // adds its backing message to the matching collection (Documents or
        // DocumentsIncremental) on the UI thread. Only used by Char/Word typing - Flow mode
        // always renders through TransformAppend directly and is unaffected by this toggle.
        private ITypingSink CreateTypingSink()
        {
            ITypingSink sink = null;
            Application.Current.Dispatcher.Invoke(() =>
            {
                if (UseIncrementalAppend)
                {
                    var engine = new Markdown { DocumentStyle = SelectedStyleInfo?.Style };
                    var message = new FlowMessage { Document = engine.Transform(string.Empty) };
                    DocumentsIncremental.Add(message);
                    sink = new IncrementalTypingSink(_pendingUpdates, message, engine);
                }
                else
                {
                    var message = new TypedMessage();
                    Documents.Add(message);
                    sink = new PlainTypingSink(_pendingUpdates, message);
                }
            });
            return sink;
        }

        private async Task StartTypingWord(string source)
        {
            if (string.IsNullOrEmpty(source)) return;
            CancelExistingAndPrepare();

            // Capture the current CTS token locally to avoid races with cancel/prepare.
            var token = _typingCts?.Token ?? System.Threading.CancellationToken.None;

                    try
                    {
                        var sink = CreateTypingSink();

                        var sb = new StringBuilder();
                        var pattern = "\\S+|\\s+";
                        var matches = Regex.Matches(source, pattern);

                        int i = 0;
                        while (i < matches.Count)
                        {
                            _pauseEvent.Wait();
                            token.ThrowIfCancellationRequested();

                            var m = matches[i];

                            // Pure whitespace token (spaces, tabs, newlines)
                            if (Regex.IsMatch(m.Value, "^\\s+$"))
                            {
                                sb.Append(m.Value);
                                sink.QueueUpdate(sb.ToString());

                                // If whitespace contains a newline, treat as block boundary and apply a standard delay
                                if (m.Value.Contains('\n') || m.Value.Contains('\r'))
                                {
                                    int delayWs = (int)(WordDelay / SpeedMultiplier);
                                    await Task.Delay(Math.Max(1, delayWs), token);
                                }

                                i++;
                                continue;
                            }

                            // Non-whitespace token (a word)
                            var word = m.Value;
                            if (word.Length <= ShortWordGroupThreshold)
                            {
                                // Group consecutive short words (<=16 chars), including following whitespace,
                                // until a long word (>16) or a whitespace containing newline is encountered.
                                var groupSb = new StringBuilder();
                                Match lastNonSpace = null;
                                while (i < matches.Count)
                                {
                                    var t = matches[i];
                                    groupSb.Append(t.Value);
                                    if (!Regex.IsMatch(t.Value, "^\\s+$"))
                                    {
                                        lastNonSpace = t;
                                        if (t.Value.Length > ShortWordGroupThreshold)
                                        {
                                            // Long word encountered: remove it from the group and break so it will be handled next
                                            groupSb.Length -= t.Value.Length;
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        // Whitespace token: if it contains newline, include it and stop grouping (block boundary)
                                        if (t.Value.Contains('\n') || t.Value.Contains('\r'))
                                        {
                                            i++; // include this whitespace in the group and advance past it
                                            break;
                                        }
                                    }
                                    i++;
                                }

                                var toAppend = groupSb.ToString();
                                if (toAppend.Length > 0)
                                {
                                    sb.Append(toAppend);
                                    // Coalesce frequent updates by storing the latest text for this message
                                    sink.QueueUpdate(sb.ToString());

                                    int delay = (int)(WordDelay / SpeedMultiplier);
                                    if (PunctuationAware && lastNonSpace != null && Regex.IsMatch(lastNonSpace.Value, "[.!?]+$"))
                                        delay = (int)(delay * PunctuationPauseMultiplier);

                                    await Task.Delay(Math.Max(1, delay), token);
                                }

                                // continue without incrementing i here because inner loop already advanced it appropriately
                                continue;
                            }

                            // Long word (>16): handle individually
                            sb.Append(word);
                            sink.QueueUpdate(sb.ToString());

                            int delayLong = (int)(WordDelay / SpeedMultiplier);
                            if (PunctuationAware && Regex.IsMatch(word, "[.!?]+$")) delayLong = (int)(delayLong * PunctuationPauseMultiplier);
                            await Task.Delay(Math.Max(1, delayLong), token);

                            i++;
                        }

                        // Apply the final text immediately rather than waiting for the next flush tick.
                        sink.ApplyFinal(sb.ToString());
                    }
            catch (OperationCanceledException)
            {
                // Cancellation requested - stop typing silently.
            }
            finally
            {
                ClearTypingToken();
            }
        }


        private async Task StartTypingFlow(string source)
        {
            if (string.IsNullOrEmpty(source)) return;

            // Cancel any existing typing and prepare UI; keep semantics of existing method.
            CancelExistingAndPrepare();

            // Reuse the CTS that CancelExistingAndPrepare already created (creating a second
            // one here would silently leak the first and orphan its cancellation wiring).
            var token = _typingCts.Token;

            try
            {
                // The Markdown engine is a DependencyObject, so it (and every FlowDocument it
                // produces) must be created on the UI thread. It is reused for every update
                // below, which all run via Dispatcher.Invoke on that same thread. Everything
                // from here on is inside the try so a setup failure still clears IsTyping
                // instead of leaving the Add button permanently disabled.
                Markdown markdownEngine = null;
                int index = -1;
                Application.Current.Dispatcher.Invoke(() =>
                {
                    markdownEngine = new Markdown { DocumentStyle = SelectedStyleInfo?.Style };
                    DocumentsFlow.Add(markdownEngine.Transform(string.Empty));
                    index = DocumentsFlow.Count - 1;
                }, System.Windows.Threading.DispatcherPriority.Render);

                var sb = new StringBuilder();
                var pattern = "\\S+|\\s+";
                var matches = Regex.Matches(source, pattern);

                const int updateIntervalMs = 50;
                int lastUpdate = Environment.TickCount;

                int i = 0;
                while (i < matches.Count)
                {
                    _pauseEvent.Wait();
                    token.ThrowIfCancellationRequested();

                    var m = matches[i];

                    // Append token to buffer (preserve original grouping logic if needed)
                    sb.Append(m.Value);

                    // If whitespace contains newline, optionally you may want to add extra delay
                    if (Regex.IsMatch(m.Value, "^\\s+$") && (m.Value.Contains('\n') || m.Value.Contains('\r')))
                    {
                        int delayWs = (int)(WordDelay / SpeedMultiplier);
                        await Task.Delay(Math.Max(1, delayWs), token);
                    }

                    // Throttle visual updates to UI thread
                    if (Environment.TickCount - lastUpdate >= updateIntervalMs || i == matches.Count - 1)
                    {
                        var text = sb.ToString();
                        lastUpdate = Environment.TickCount;

                        // Render the accumulated markdown so far and replace the collection item.
                        Application.Current.Dispatcher.Invoke(new Action(() =>
                        {
                            DocumentsFlow[index] = markdownEngine.Transform(text);
                        }), System.Windows.Threading.DispatcherPriority.Render);
                        RaiseContentUpdated();
                    }

                    // Use captured token for delay and cancellation
                    int delay = (int)(WordDelay / SpeedMultiplier);
                    await Task.Delay(Math.Max(1, delay), token);

                    i++;
                }
            }
            catch (OperationCanceledException)
            {
                // expected on cancellation - swallow or handle as before
            }
            finally
            {
                ClearTypingToken();
            }
        }

        private void CancelExistingAndPrepare()
        {
            // cancel previous typing
            _typingCts?.Cancel();
            _typingCts?.Dispose();
            _typingCts = new System.Threading.CancellationTokenSource();
            // ensure not paused
            _pauseEvent.Set();
            IsPaused = false;
            IsTyping = true;
        }

        private void ClearTypingToken()
        {
            _typingCts?.Dispose();
            _typingCts = null;
            IsTyping = false;
        }

        private void CancelTyping()
        {
            _typingCts?.Cancel();
            ClearTypingToken();
        }

        private void TogglePause()
        {
            if (_typingCts == null) return;
            if (IsPaused)
            {
                _pauseEvent.Set();
                IsPaused = false;
            }
            else
            {
                _pauseEvent.Reset();
                IsPaused = true;
            }
        }
    }
    /// <summary>
    /// Simple ICommand implementation for demo purposes
    /// </summary>
    public class DelegateCommand : System.Windows.Input.ICommand
    {
        private readonly Action _execute;
        private readonly Func<bool> _canExecute;
        public DelegateCommand(Action execute, Func<bool> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }
        public bool CanExecute(object parameter) => _canExecute?.Invoke() ?? true;
        public void Execute(object parameter) => _execute();
        // Tie into WPF's requery mechanism so bound buttons re-evaluate CanExecute
        // whenever CommandManager.InvalidateRequerySuggested() is called.
        public event EventHandler CanExecuteChanged
        {
            add { System.Windows.Input.CommandManager.RequerySuggested += value; }
            remove { System.Windows.Input.CommandManager.RequerySuggested -= value; }
        }
    }
    public class StyleInfo
    {
        public string Name { set; get; }
        public Style Style { set; get; }

        public StyleInfo(string name, Style style)
        {
            Name = name;
            Style = style;
        }

        public override int GetHashCode()
        {
            return Name.GetHashCode();
        }

        public override bool Equals(object val)
        {
            if (val is StyleInfo sf)
            {
                return Name == sf.Name;
            }
            else return false;
        }

        public static bool operator ==(StyleInfo left, StyleInfo right)
        {
            if (Object.ReferenceEquals(left, right)) return true;
            if (Object.ReferenceEquals(left, null)) return false;
            return left.Equals(right);
        }

        public static bool operator !=(StyleInfo left, StyleInfo right)
        {
            return !(left == right);
        }
    }
}