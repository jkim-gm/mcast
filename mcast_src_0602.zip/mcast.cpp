#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <time.h>
#include <sys/stat.h>
#include <dirent.h>
#include <ctype.h>
#include <sys/syscall.h>

#include <curl/curl.h>

#include <pthread.h>
#include <sys/un.h>

#include <iostream>
#include <sstream>
#include <string>
#include <mutex>
#include <list>
#include <vector>
#include <condition_variable>
#include <stdarg.h>

#include "cJSON.h"

#define _EN_SCHEDULE_THREAD

#define VERSION     "20260602"
#define MAX_RCVBUF	4096
#define BUFSIZE     2048
#define FORBIDDEN   403
#define NOTFOUND    404
#define MAX_CLIENT  16

typedef struct {
    char buf[MAX_RCVBUF];
    int  len;
} ClientContext;

ClientContext g_client_ctx[MAX_CLIENT];

int g_iPrtLog = 1;
int g_iWrtLog = 0;
int g_iPrtDbg = 0;
int g_iPrtOnly = 0; // ONLY FOR TEST.

char m_rp[256] = { 0 };
char m_gr[256] = { 0 };
char m_m0[256] = { 0 };
char m_m1[256] = { 0 };
char m_ch[256] = { 0 };
char m_ap[256] = { 0 };
char m_ad[256] = { 0 };
char m_key[64] = { 0 };
char m_saveTs[512] = { 0 };

typedef struct {
	time_t begin;
	time_t end;
	std::string type;
	std::string vod;
	std::string key;
	std::string save;
	std::string preimg;
	std::string postimg;
	std::string pauseimg;
	std::string mrcv;
	int			state;
} SCHEDULE;

typedef enum { eST_NONE = 0, eST_ONPREAIR, eST_ONAIR, eST_ONPOSTAIR, eST_ONVOD, eST_FINISHED } eSTATUS;

std::vector<SCHEDULE>	m_lstSchd;
std::mutex				m_mtxSchd;
std::mutex				m_mtxAdv;
pthread_t	schedule_pthread;
pthread_t	mcastadv_pthread;
pthread_t	mcastsvr0_pthread;
pthread_t	mcastsvr1_pthread;

pthread_t	mcastsvr_pthread;

bool		m_bIsOnAdv = false;
bool		m_bIsOnLive = false;
std::string m_curAdv = "";
std::string m_newAdv = "";
int			m_OnMcastSvr = 0;
bool		m_bAppExit = false;
std::string m_rtmpRcv0 = "";
std::string m_rtmpRcv1 = "";

int		 mCurOnAirSvr = -1;
int		 mOnAirStat0 = eST_NONE;
int		 mOnAirStat1 = eST_NONE;
SCHEDULE mCurSchd0 = { 0 };
SCHEDULE mCurSchd1 = { 0 };

///////////////////////////////////////////////////////////////////////////////
// Definition
///////////////////////////////////////////////////////////////////////////////
#define _FORKx
#define _VC_DEBUGx


#define	IPSOC_MAXLEN	5

typedef struct {
	int	 iCmd;
	int	 iStatus;
	int  iYear;
	int  iMonth;
	int  iPlayTime;
	long int liStrmSize;
	char vdShortId[32];
	char empNo[16];
	char vdRes[16];
} IPSOCDATA;

typedef enum { eREADY = 0, eSTART = 1, eSING = 2, eONAIR = 3, eSTOP = 4 } eSTAT;
typedef enum { eRTMP_Start = 10, eRTMP_Sing = 11, eRTMP_OnAir = 12, eRTMP_Timeout = 13, eRTMP_Stop = 14, eRTMP_Heartbeat = 15 } eRTMPSVR;
typedef enum { eLIVE_Start = 20, eLIVE_Stop = 21, eLIVE_GetCfg = 22, eLIVE_SetCfg = 23 } eLIVESVR;
typedef enum { eRESTAPI_Sing = 30, eRESTAPI_OnAir = 31, eRESTAPI_StrmInfo = 32 } eRESTAPI;

///////////////////////////////////////////////////////////////////////////////
// utils/debugger
///////////////////////////////////////////////////////////////////////////////
#define prt(m, ...)	__prt(m, ## __VA_ARGS__)
//#define prt(m, ...)	__prt_d(__FUNCTION__, m, ## __VA_ARGS__)

void __wrt(const char* _m)
{
	int fd = 0;
	if ((fd = open("/mcast/mcast.log", O_CREAT | O_WRONLY | O_APPEND, 0644)) >= 0) {
		time_t tmt = time(NULL);
		struct tm tmn = *localtime(&tmt);
		char pLog[1024];
		sprintf(pLog, "%02d-%02d %02d:%02d:%02d> %s\n",
			tmn.tm_mon + 1, tmn.tm_mday, tmn.tm_hour, tmn.tm_min, tmn.tm_sec, _m);
		write(fd, pLog, strlen(pLog));
		close(fd);
	}
}

void __prt(const char* _m, ...)
{
	char msg[1024] = { 0 };
	char strTm[32] = { 0 };

	time_t now = time(NULL);
    struct tm *t = localtime(&now);
	strftime(strTm, sizeof(strTm), "%m-%d %H:%M:%S", t);

	va_list vl;
	va_start(vl, _m);
	vsprintf((char*)msg, _m, vl);
	va_end(vl);

	if (g_iPrtLog) {
		printf("%s> %s", strTm, (char*)msg);
	}
	if (g_iWrtLog) {
		__wrt(msg);
	}
}

void __prt_d(const char* _f, const char* _m, ...)
{
	char msg[1024] = { 0 };

	va_list vl;
	va_start(vl, _m);
	int len = sprintf((char*)msg, "(%s) ", _f);
	vsprintf((char*)msg + len, _m, vl);
	va_end(vl);

	if (g_iPrtLog) {
		printf("%s", (char*)msg);
	}
	if (g_iWrtLog) {
		__wrt(msg);
	}
}

long long getUnixTimeMs()
{
	struct timeval tp;
	gettimeofday(&tp, NULL);
	long long cur_ms = tp.tv_sec * 1000 + tp.tv_usec / 1000;
	return cur_ms;
}

long long getUnixTimeUs()
{
	struct timeval tp;
	gettimeofday(&tp, NULL);
	long long cur_ms = tp.tv_sec * 1000000 + tp.tv_usec;
	return cur_ms;
}

///////////////////////////////////////////////////////////////////////////////
// sigterm handler
///////////////////////////////////////////////////////////////////////////////
void sig_term_handler(int signum, siginfo_t* info, void* ptr)
{
	prt("sig_term -> exit\n");
	m_bAppExit = true;
}

void catch_sigterm()
{
	static struct sigaction _sigact;

	memset(&_sigact, 0, sizeof(_sigact));
	_sigact.sa_sigaction = sig_term_handler;
	_sigact.sa_flags = SA_SIGINFO;

	sigaction(SIGTERM, &_sigact, NULL);	// Kill
	sigaction(SIGINT, &_sigact, NULL);	// ^C
}

///////////////////////////////////////////////////////////////////////////////
// parse_value
///////////////////////////////////////////////////////////////////////////////
int parse_value(char* pIn, const char* pKey, char* pValue)
{
	int iLen = 0;
	if (!pIn)
		return -1;

	char* pBeg = strstr(pIn, pKey);
	if (!pBeg)
		return -1;

	int iLenKey = (int)strlen(pKey);
	char* pEnd = strstr(pBeg + iLenKey, "&");
	if (pEnd) {
		iLen = (int)(pEnd - (pBeg + iLenKey));
	}
	else {
		pEnd = pBeg + iLenKey;
		while (!(pEnd[iLen] == '\0' || pEnd[iLen] == ',' || pEnd[iLen] == ' ' || pEnd[iLen] == '\n' || pEnd[iLen] == '}')) {
			iLen++;
		}
	}

	int o = 0;
	for (int i = 0; i < 256 && i < iLen; i++) {
		int idx = iLenKey + i;
		if (pBeg[idx] != '\"') {
			pValue[o++] = pBeg[idx];
		}
	}
	pValue[o] = '\0';

	return o;
}

///////////////////////////////////////////////////////////////////////////////
// parse_schedule
///////////////////////////////////////////////////////////////////////////////
int parse_schedule(char* pIn)
{
	int iLen = 0;
	if (!pIn)
		return -1;

	m_lstSchd.clear();

	char* pBeg = strcasestr(pIn, "Content-Length:");
	if (!pBeg)
		return -1;
	
	pBeg = strstr(pBeg, "\r\n\r\n");
	if (!pBeg)
		return -1;
	pBeg += 4;

	//prt(pBeg);
	//prt("\n");

	prt("---- schedule begin ----\n%s\n", (char*)pBeg);

	cJSON* json = cJSON_Parse(pBeg);
	if (!json) {
		const char *error_ptr = cJSON_GetErrorPtr();
		prt("err> %s\n", (char*)error_ptr);
		prt("---- schedule failed ----\n");
		return -1;
	}

	cJSON* jsList = cJSON_GetObjectItemCaseSensitive(json, "list");
	if (jsList) {
		if (cJSON_IsArray(jsList)) {
			cJSON* jsItm = jsList->child;
			cJSON* jsVal = nullptr;
			while (jsItm) {

				SCHEDULE schd;
				tm begin, end;
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "begin");
				if (jsVal && jsVal->type == cJSON_String) {
					std::string strval = jsVal->valuestring;
					begin.tm_year = atoi(strval.substr(0, 4).c_str()) - 1900;
					begin.tm_mon = atoi(strval.substr(5, 2).c_str()) - 1;
					begin.tm_mday = atoi(strval.substr(8, 2).c_str());
					begin.tm_hour = atoi(strval.substr(11, 2).c_str());
					begin.tm_min = atoi(strval.substr(14, 2).c_str());
					begin.tm_sec = atoi(strval.substr(17, 2).c_str());
					schd.begin = mktime(&begin);
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "end");
				if (jsVal && jsVal->type == cJSON_String) {
					std::string strval = jsVal->valuestring;
					end.tm_year = atoi(strval.substr(0, 4).c_str()) - 1900;
					end.tm_mon = atoi(strval.substr(5, 2).c_str()) - 1;
					end.tm_mday = atoi(strval.substr(8, 2).c_str());
					end.tm_hour = atoi(strval.substr(11, 2).c_str());
					end.tm_min = atoi(strval.substr(14, 2).c_str());
					end.tm_sec = atoi(strval.substr(17, 2).c_str());
					schd.end = mktime(&end);
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "key");
				if (jsVal && jsVal->type == cJSON_String) {
					schd.key = jsVal->valuestring;
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "type");
				if (jsVal && jsVal->type == cJSON_String) {
					schd.type = jsVal->valuestring;
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "vod");
				if (jsVal && jsVal->type == cJSON_String) {
					schd.vod = jsVal->valuestring;
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "save");
				if (jsVal && jsVal->type == cJSON_String) {
					schd.save = jsVal->valuestring;
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "preimg");
				if (jsVal && jsVal->type == cJSON_String) {
					schd.preimg = jsVal->valuestring;
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "postimg");
				if (jsVal && jsVal->type == cJSON_String) {
					schd.postimg = jsVal->valuestring;
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "pauseimg");
				if (jsVal && jsVal->type == cJSON_String) {
					schd.pauseimg = jsVal->valuestring;
				}
				schd.mrcv = "";
				schd.state = eST_NONE;

				prt(" - %4d%02d%02d %02d:%02d:%02d ~ %4d%02d%02d %02d:%02d:%02d\n",
					begin.tm_year, begin.tm_mon, begin.tm_mday,
					begin.tm_hour, begin.tm_min, begin.tm_sec,
					end.tm_year, end.tm_mon, end.tm_mday,
					end.tm_hour, end.tm_min, end.tm_sec);
				//prt(" - %lld - %lld\n", schd.begin, schd.end);
				prt(" - key.%s, type.%s, vod.%s, save.%s\n",
					schd.key.c_str(), schd.type.c_str(), schd.vod.c_str(), schd.save.c_str());
				prt(" - pre.%s, post.%s, pause%s\n",
					schd.preimg.c_str(), schd.postimg.c_str(), schd.pauseimg.c_str());

				m_lstSchd.push_back(schd);
				jsItm = jsItm->next;
				prt(" - next\n");
			} // while (jsItm)
		} // if (cJSON_IsArray)
	} // if (jsList)

	if (json) {
		cJSON_Delete(json);
	}

	prt("---- schedule end ----\n");

	return iLen;
}

int parse_schedule_ex(char* pIn)
{
	if (!pIn) {
		return -1;
	}
	m_lstSchd.clear();
	prt("---- schedule begin ----\n");

	cJSON* json = cJSON_Parse(pIn);
	if (!json) {
		const char *error_ptr = cJSON_GetErrorPtr();
		prt("err> %s\n", (char*)pIn);
		prt("---- schedule failed ----\n");
		return -1;
	}

	cJSON* jsList = cJSON_GetObjectItemCaseSensitive(json, "list");
	if (jsList) {
		if (cJSON_IsArray(jsList)) {
			cJSON* jsItm = jsList->child;
			cJSON* jsVal = nullptr;
			while (jsItm) {
				SCHEDULE schd;
				tm begin, end;
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "begin");
				if (jsVal && jsVal->type == cJSON_String) {
					std::string strval = jsVal->valuestring;
					prt("%s\n", strval.c_str());
					begin.tm_year = atoi(strval.substr(0, 4).c_str()) - 1900;
					begin.tm_mon = atoi(strval.substr(5, 2).c_str()) - 1;
					begin.tm_mday = atoi(strval.substr(8, 2).c_str());
					begin.tm_hour = atoi(strval.substr(11, 2).c_str());
					begin.tm_min = atoi(strval.substr(14, 2).c_str());
					begin.tm_sec = atoi(strval.substr(17, 2).c_str());
					schd.begin = mktime(&begin);
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "end");
				if (jsVal && jsVal->type == cJSON_String) {
					std::string strval = jsVal->valuestring;
					end.tm_year = atoi(strval.substr(0, 4).c_str()) - 1900;
					end.tm_mon = atoi(strval.substr(5, 2).c_str()) - 1;
					end.tm_mday = atoi(strval.substr(8, 2).c_str());
					end.tm_hour = atoi(strval.substr(11, 2).c_str());
					end.tm_min = atoi(strval.substr(14, 2).c_str());
					end.tm_sec = atoi(strval.substr(17, 2).c_str());
					schd.end = mktime(&end);
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "key");
				if (jsVal && jsVal->type == cJSON_String) {
					schd.key = jsVal->valuestring;
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "type");
				if (jsVal && jsVal->type == cJSON_String) {
					schd.type = jsVal->valuestring;
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "vod");
				if (jsVal && jsVal->type == cJSON_String) {
					schd.vod = jsVal->valuestring;
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "save");
				if (jsVal && jsVal->type == cJSON_String) {
					schd.save = jsVal->valuestring;
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "preimg");
				if (jsVal && jsVal->type == cJSON_String) {
					schd.preimg = jsVal->valuestring;
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "postimg");
				if (jsVal && jsVal->type == cJSON_String) {
					schd.postimg = jsVal->valuestring;
				}
				jsVal = cJSON_GetObjectItemCaseSensitive(jsItm, "pauseimg");
				if (jsVal && jsVal->type == cJSON_String) {
					schd.pauseimg = jsVal->valuestring;
				}
				schd.mrcv = "";
				schd.state = eST_NONE;

				prt("%4d.%02d.%02d %02d:%02d:%02d ~ %4d.%02d.%02d %02d:%02d:%02d\n",
					begin.tm_year+1900, begin.tm_mon+1, begin.tm_mday,
					begin.tm_hour, begin.tm_min, begin.tm_sec,
					end.tm_year+1900, end.tm_mon+1, end.tm_mday,
					end.tm_hour, end.tm_min, end.tm_sec);
				prt("%lld - %lld\n", schd.begin, schd.end);
				prt("key.%s, type.%s, vod.%s, save.%s\n",
					schd.key.c_str(), schd.type.c_str(), schd.vod.c_str(), schd.save.c_str());
				prt("pre.%s, post.%s, pause%s\n",
					schd.preimg.c_str(), schd.postimg.c_str(), schd.pauseimg.c_str());

				m_lstSchd.push_back(schd);
				jsItm = jsItm->next;
				prt(" - next -\n");
			} // while (jsItm)
		} // if (cJSON_IsArray)
	} // if (jsList)

	if (json) {
		cJSON_Delete(json);
	}

	prt("---- schedule end ----\n");

	return 0;
}

///////////////////////////////////////////////////////////////////////////////
// mcastadv_stop/thread/start()
///////////////////////////////////////////////////////////////////////////////
void mcastadv_stop()
{
	prt("stop advertisement [In]%s [Out]udp://%s:%s\n", m_curAdv.c_str(), m_gr, m_ch);

	char	kcmd[64] = "killall -9 mcastadv";
	FILE* pfp = popen(kcmd, "r");
	if (pfp) pclose(pfp);

	m_bIsOnAdv = false;
}

void* mcastadv_thread(void* arg)
{
	prt("started advertisement [In]%s [Out]udp://%s:%s\n", m_curAdv.c_str(), m_gr, m_ch);
	m_bIsOnAdv = true;

	char	cmd[1024] = { 0 };
	sprintf(cmd, "/mcast/mcastadv -re -stream_loop -1 -v quiet -i %s -c copy -f mpegts -thread_queue_size 8192 \"udp://%s:%s?pkt_size=1316&fifo_size=1000000&overrun_nonfatal=1&bitrate=15000000\"",
		m_curAdv.c_str(), m_gr, m_ch);
	FILE* pfp = popen(cmd, "r");
	if (pfp) pclose(pfp);

	m_bIsOnAdv = false;
	return nullptr;
}

void mcastadv_start()
{
	prt("starting advertisement...\n");
	usleep(5000 * 1000);
	pthread_create(&mcastadv_pthread, NULL, mcastadv_thread, NULL);
}

///////////////////////////////////////////////////////////////////////////////
// mcastsvr_stop/thread/start()
///////////////////////////////////////////////////////////////////////////////
void mcastsvr_stop(int idx)
{
	char	kcmd[64] = "killall -9 mcastsvr";
	FILE* pfp = popen(kcmd, "r");
	if (pfp) pclose(pfp);
	pthread_join(mcastsvr0_pthread, NULL);

	//---- SEND POST
	if (mCurSchd0.save.length() > 0) {
		prt(" API: post [http://127.0.0.1:%s/api/hytube/mcast_broadcaster/v1/broadcaster/end]\n", m_ap);
		int dursec = (int)(mCurSchd0.end - mCurSchd0.begin);
		char cmd[512] = "\0";
		sprintf(cmd, "/mcast/restapi -mcastliveend http://127.0.0.1:%s/api/hytube/mcast_broadcaster/v1/broadcaster/end %d %s %s",
			m_ap, dursec, mCurSchd0.save.c_str(), mCurSchd0.key.c_str());
		pfp = popen(cmd, "r");
		if (pfp) pclose(pfp);
	}

	mCurSchd0.begin = 0;
	mCurSchd0.end = 0;
	mCurSchd0.key = "";
	m_bIsOnLive = false;
}

static void* mcastsvr0_thread(void* arg)
{
	m_bIsOnLive = true;

	char	cmd[2048] = { 0 };
	char	saveTs[512] = { 0 };
	FILE*	pfp;

	//prt("%s\n", mCurSchd0.type.c_str());
	//prt("%s\n", mCurSchd0.save.c_str());
	//prt("%s\n", mCurSchd0.key.c_str());
	//prt("%s\n", mCurSchd0.mrcv.c_str());

	if (mCurSchd0.type.compare("live")==0) {
		if (mCurSchd0.save.length() > 0) {

			std::string dir;
			size_t pos = mCurSchd0.save.find_last_of('/');
			//prt(" - %s, %d\n", mCurSchd0.save.c_str(), pos);
			dir = mCurSchd0.save.substr(0, pos);
			//prt(" - %s\n", dir);
			sprintf(cmd, "mkdir -p %s; chmod 755 %s", dir.c_str(), dir.c_str());
			//prt(" - %s\n", cmd);

			pfp = popen(cmd, "r");
			if (pfp) pclose(pfp);
			
			sprintf(saveTs, "-c copy -f hls -hls_time 2 -hls_segment_type mpegts -hls_list_size 0 -hls_flags append_list %s",
				mCurSchd0.save.c_str());
		}
		else {
			saveTs[0] = '\0';
		}
		strcpy(m_saveTs, saveTs);

		prt("started live broadcast [In]rtmp://%s/%s [Out]udp://%s:%s [Save]%s [Time]%ld~%ld\n",
			mCurSchd0.mrcv.c_str(), mCurSchd0.key.c_str(), m_gr, m_ch, saveTs,
			mCurSchd0.begin, mCurSchd0.end);

		sprintf(cmd, "/mcast/mcastsvr -listen 1 -timeout -1 -tmb%ld -tme%ld -tmx0 -analyzeduration 2000000 -v quiet -i rtmp://%s/%s -y -c copy -f mpegts -thread_queue_size 8192 \"udp://%s:%s?pkt_size=1316&fifo_size=1000000&overrun_nonfatal=1&bitrate=15000000\" %s",
			mCurSchd0.begin, mCurSchd0.end,
			mCurSchd0.mrcv.c_str(), mCurSchd0.key.c_str(),
			m_gr, m_ch, saveTs);

		pfp = popen(cmd, "r");
		if (pfp) pclose(pfp);

		//---- RESTAPI:POST RECORDING DONE
		if (mCurSchd0.save.length() > 0) {
			prt(" API: post [http://127.0.0.1:%d/api/hytube/mcast_broadcaster/v1/broadcaster/end]\n", m_ap);
			int dursec = (int)(mCurSchd0.end - mCurSchd0.begin);
			sprintf(cmd, "/mcast/restapi -mcastliveend http://127.0.0.1:%s/api/hytube/mcast_broadcaster/v1/broadcaster/end %d %s %s",
				m_ap, dursec, mCurSchd0.save.c_str(), mCurSchd0.key.c_str());
			pfp = popen(cmd, "r");
			if (pfp) pclose(pfp);		
		}

		m_saveTs[0] = '\0';
	}
	else if (mCurSchd0.type.compare("vod")==0 && mCurSchd0.vod.length() > 0) {

		m_saveTs[0] = '\0';

		prt("started vod broadcast [In]rtmp://%s/%s [Out]udp://%s:%s [Time]%ld~%ld\n",
			mCurSchd0.mrcv.c_str(), mCurSchd0.key.c_str(), m_gr, m_ch,
			mCurSchd0.begin, mCurSchd0.end);

		sprintf(cmd, "/mcast/mcastsvr -re -stream_loop -1 -tmb%ld -tme%ld -tmx0 -v quiet -i %s -c copy -fflags +genpts+igndts+ignidx -f mpegts -thread_queue_size 8192 \"udp://%s:%s?pkt_size=1316&fifo_size=1000000&overrun_nonfatal=1&bitrate=15000000\"",
			mCurSchd0.begin, mCurSchd0.end,
			mCurSchd0.vod.c_str(), m_gr, m_ch);

		pfp = popen(cmd, "r");
		if (pfp) pclose(pfp);
	}
	
	mCurSchd0.begin = 0;
	mCurSchd0.end = 0;
	mCurSchd0.key = "";
	m_bIsOnLive = false;
	return nullptr;
}

static void* mcastsvr1_thread(void* arg)
{	
	return nullptr;
}

void mcastsvr_start(int idx)
{
	prt("starting live broadcast...\n");
	usleep(5000 * 1000);
	if (idx == 0) {
		pthread_create(&mcastsvr0_pthread, NULL, mcastsvr0_thread, NULL);
	}
	else if (idx == 1) {
		pthread_create(&mcastsvr1_pthread, NULL, mcastsvr1_thread, NULL);
	}
}

void schedule_copy(SCHEDULE* sa, SCHEDULE* sb)
{
	sa->begin = sb->begin;
	sa->end = sb->end;
	sa->type = sb->type;
	sa->vod = sb->vod;
	sa->key = sb->key;
	sa->save = sb->save;
	sa->preimg = sb->preimg;
	sa->postimg = sb->postimg;
	sa->pauseimg = sb->pauseimg;
	sa->mrcv = sb->mrcv;
	sa->state = sb->state;
}

///////////////////////////////////////////////////////////////////////////////
// schedule_issame()
///////////////////////////////////////////////////////////////////////////////
bool schedule_issame(SCHEDULE sa, SCHEDULE sb)
{
	if (sa.begin != sb.begin || sa.end != sb.end)
		return false;
	if (sa.key.compare(sb.key) != 0)
		return false;

	return true;
}

///////////////////////////////////////////////////////////////////////////////
// schedule_isonair()
///////////////////////////////////////////////////////////////////////////////
int schedule_isonair(SCHEDULE* schd0)
{
	int onair = -1;
	time_t tNow = time(NULL);	
	struct tm tmNow = *localtime(&tNow);
	//tmNow.tm_year += 1900;
	//tmNow.tm_mon += 1;
	//tmNow.tm_hour += 9;
	tNow = mktime(&tmNow);

	time_t tExtra = 0;// 15 * 60; // 15 min
	schd0->begin = 0;
	schd0->end = 0;

	m_mtxSchd.lock();
	for (size_t i = 0; i < m_lstSchd.size(); i++) {

		SCHEDULE* schd = &m_lstSchd[i];

		//prt("%d %ld ~(%d)~ %ld year.%d %d-%d %d-%d-%d\n", i, schd->begin, tNow, schd->end, tmNow.tm_year, tmNow.tm_mon, tmNow.tm_mday,
		//	tmNow.tm_hour, tmNow.tm_min, tmNow.tm_sec);

		if (schd->begin <= tNow && tNow < schd->end) {
			schd->state = eST_ONAIR;
			schedule_copy(schd0, schd);
			onair = i;
			break;
		}
		else if (schd->end <= tNow) {
			schd->state = eST_FINISHED;
		}
	}
	m_mtxSchd.unlock();

	return onair;
}

///////////////////////////////////////////////////////////////////////////////
// schedule_thread
///////////////////////////////////////////////////////////////////////////////
void* schedule_thread(void* arg)
{
	prt("start schedule_thread\n");

	time_t tNow = time(NULL);
	time_t tPrv = tPrv;

	int eST_AD_FAILED = -100;

	int iStat = -1;
	int isAdv = 0;
	int isPrg = 0;

	mCurSchd0.begin = 0;
	mCurSchd0.end = 0;
	mCurSchd1.begin = 0;	
	mCurSchd1.end = 0;

	while (!m_bAppExit) {
		usleep(10 * 1000);	// 10 ms

		tNow = time(NULL);
		struct tm tmNow = *localtime(&tNow);
		//tmNow.tm_year += 1900;
		tNow = mktime(&tmNow);

		if (tNow != tPrv) {
			tPrv = tNow;

			//---- CHECK THE SCHEDULE
			static SCHEDULE schd0 = { 0 };
			static SCHEDULE schd1 = { 0 };
			int iOnAir = schedule_isonair(&schd0);
			if (iOnAir == -1) {	

				if (m_bIsOnLive) {
					//prt("kill mcastsvr0\n");
					char	kcmd[64] = "killall -9 mcastsvr";
					FILE* pfp = popen(kcmd, "r");
					if (pfp) pclose(pfp);
					pthread_join(mcastsvr0_pthread, NULL);
					continue;
				}
				///////////////////////////////////////////////////////////////////////////////
				// NOTHING TO ONAIR => ADV.
				if (m_newAdv.size() <= 0 && m_bIsOnAdv) {
					// STOP ADV.
					m_curAdv = m_newAdv;
					mcastadv_stop();
				}
				else if (m_newAdv.size() > 0 && !m_bIsOnAdv) {
					// UPDATE NEW ADV.
					m_curAdv = m_newAdv;
					pthread_join(mcastadv_pthread, NULL);
					pthread_join(mcastsvr0_pthread, NULL);
					mcastadv_start();
				}
				else if (m_newAdv.size() > 0) {
					// START ADV.
					if (m_newAdv.compare(m_curAdv)==0) {
						// KEEP ADV.
					}
					else {
						// UPDATE NEW ADV.
						m_curAdv = m_newAdv;
						mcastadv_stop();
						pthread_join(mcastadv_pthread, NULL);
						pthread_join(mcastsvr0_pthread, NULL);
						mcastadv_start();
					}
				}
			}
			else if (iOnAir >= 0) {
				if (schd0.begin > 0 && schd0.end > 0) {
					if (!m_bIsOnLive) {
						// START LIVE0 (ONAIR)
						if (m_newAdv.size() > 0 && !m_bIsOnAdv) {
							// UPDATE NEW ADV.
							m_curAdv = m_newAdv;
							pthread_join(mcastadv_pthread, NULL);
							pthread_join(mcastsvr0_pthread, NULL);
							mcastadv_start();
						}
						schedule_copy(&mCurSchd0, &schd0);
						mCurSchd0.mrcv = m_rtmpRcv0;
						mcastsvr_start(0);
					}
					else {
						// ON LIVE0
						// v20220627 RESTART ON PROGRAM CHANGED.
						if (schd0.key.compare(mCurSchd0.key) != 0) {
							// PROGRAM CHANGED
							char	kcmd[64] = "killall -9 mcastsvr";
							FILE* pfp = popen(kcmd, "r");
							if (pfp) pclose(pfp);
							pthread_join(mcastsvr0_pthread, NULL);

							schedule_copy(&mCurSchd0, &schd0);
							mCurSchd0.mrcv = m_rtmpRcv0;
							mcastsvr_start(0);
						}
						if (m_newAdv.compare(m_curAdv) != 0) {
							m_curAdv = m_newAdv;
							if (m_newAdv.size() <= 0) {
								mcastadv_stop();
							}
							else if (m_newAdv.size() > 0) {
								mcastadv_stop();
								pthread_join(mcastadv_pthread, NULL);
								mcastadv_start();
							}
						}
					}
				}
			}

			if((tmNow.tm_sec%10)==5) {
				struct tm tb = {0};
				struct tm te = {0};
				if(iOnAir>=0) {
					tb = *localtime(&schd0.begin);
					te = *localtime(&schd0.end);
				}
				prt("adv=%s(%s) live=%s(rtmp=%s/%s,save=%s) udp=%s:%s sch=%02d:%02d~%02d:%02d\n", 
					m_bIsOnAdv?"on":"off", m_curAdv.c_str(),
					m_bIsOnLive?"on":"off", 
					mCurSchd0.mrcv.c_str(), mCurSchd0.key.c_str(), m_saveTs,
					m_gr, m_ch,
					tb.tm_hour, tb.tm_min, te.tm_hour, te.tm_min);
			}
		}
	}

	prt("exit schedule_thread\n");
	return nullptr;
}


///////////////////////////////////////////////////////////////////////////////
// apisvr_proc
///////////////////////////////////////////////////////////////////////////////
void apisvr_write_response(int fd, char* retbuf)
{
	//---- WRITE RESPONSE
	write(fd, retbuf, strlen(retbuf));
	usleep(100 * 1000);
	//---- CLOSE SOCKET
	close(fd);
}

void apisvr_write_response_ok(int fd, const char* api_header, char* retbuf)
{
	//---- FILL RESPONSE OK
	std::string strRet = "{\"ret\":\"OK\"}";
	sprintf(retbuf + strlen(api_header), "nContent-Length: %d\r\n\r\n%s", (int)strRet.size(), strRet.c_str());
	apisvr_write_response(fd, retbuf);
}

void apisvr_proc(int fd, int hit)
{
	prt("API procedure\n");
	int ir = 0;
	int ret;
	char buffer[BUFSIZE + 1];
	char retbuf[BUFSIZE];
	memset(buffer, 0, BUFSIZE + 1);
	memset(retbuf, 0, BUFSIZE);

	ret = (int)read(fd, buffer, BUFSIZE);
	if (ret == 0 || ret == -1) {
		prt("failed to read web browser request\n");
	}
	if (ret > 0 && ret < BUFSIZE)
		buffer[ret] = 0;
	else
		buffer[0] = 0;

	char value[256] = { 0 };
	const char api_Init[] = "POST /init";
	const char api_init[] = "post /init";
	const char api_Setad[] = "POST /setad";
	const char api_setad[] = "post /setad";
	const char api_Schedule[] = "POST /schedule";
	const char api_schedule[] = "post /schedule";
	const char api_Getmrcv[] = "POST /getmrcv";
	const char api_getmrcv[] = "post /getmrcv";

	const char api_Start[] = "GET /start";
	const char api_start[] = "get /start";
	const char api_Stop[] = "GET /stop";
	const char api_stop[] = "get /stop";
	const char api_Status[] = "GET /status";
	const char api_status[] = "get /status";

	const char api_Exit[] = "GET /exit";
	const char api_exit[] = "get /exit";

	const char api_header[] = "HTTP/1.1 200 OK\r\nServer: mcast\r\nConnection: close\r\nContent-Type: nContent-Type: json\r\n";
	sprintf(retbuf, "%s", api_header);

	//---- PROCESS ARGUMENTS
	if (strncmp(buffer, api_init, strlen(api_init)) == 0 || strncmp(buffer, api_Init, strlen(api_Init)) == 0)
	{
		prt("api_init\n");
		// API_INIT
		ir = parse_value(buffer, "\"rp\":", m_rp);		
		if (ir < 0) { prt("failed to parse value\n"); } else prt("rp=%s\n", m_rp);
		ir = parse_value(buffer, "\"group\":", m_gr);	
		if (ir < 0) { prt("failed to parse value\n"); } else prt("group=%s\n", m_gr);
		ir = parse_value(buffer, "\"mrcv0\":", m_m0);
		m_rtmpRcv0 = m_m0;
		if (ir < 0) { prt("failed to parse value\n"); } else prt(" - mrcv0=%s\n", m_m0);
		ir = parse_value(buffer, "\"mrcv1\":", m_m1);
		m_rtmpRcv1 = m_m1;
		if (ir < 0) { prt("failed to parse value\n"); } else prt(" - mrcv1=%s\n", m_m1);
		ir = parse_value(buffer, "\"chport\":", m_ch);
		if (ir < 0) { prt("failed to parse value\n"); } else prt(" - chport=%s\n", m_ch);
		ir = parse_value(buffer, "\"apiport\":", m_ap);
		if (ir < 0) { prt("failed to parse value\n"); } else prt(" - apiport=%s\n", m_ap);

		apisvr_write_response_ok(fd, api_header, retbuf);

		m_newAdv = "";
		m_mtxSchd.lock();
		m_lstSchd.clear();
		m_mtxSchd.unlock();
		mcastsvr_stop(0);
	}
	else if (strncmp(buffer, api_setad, strlen(api_setad)) == 0 || strncmp(buffer, api_Setad, strlen(api_Setad)) == 0)
	{		
		//---- API_SETAD
		m_mtxAdv.lock();
		ir = parse_value(buffer, "\"ad\":", value);
		prt("api_setad [%s]\n", value);
		if (ir < 0) {
			prt("failed to parse value\n");
		}
		else {
			m_newAdv = value;
		}
		m_mtxAdv.unlock();

		apisvr_write_response_ok(fd, api_header, retbuf);
	}
	else if (strncmp(buffer, api_schedule, strlen(api_schedule)) == 0 || strncmp(buffer, api_Schedule, strlen(api_Schedule)) == 0)
	{
		prt("api_setschedule\n");
		//---- API_SETSCHEDULE
		m_mtxSchd.lock();
		parse_schedule(buffer);
		m_mtxSchd.unlock();

		apisvr_write_response_ok(fd, api_header, retbuf);
	}
	else if (strncmp(buffer, api_getmrcv, strlen(api_getmrcv)) == 0 || strncmp(buffer, api_Getmrcv, strlen(api_Getmrcv)) == 0)
	{
		prt("api_getmrcv\n");
		//---- API_GETMRCV
		ir = parse_value(buffer, "\"key\":", m_key);
		if (ir < 0) { 
			prt("failed to parse value\n");
			std::string strRet = "{\"ret\":\"Failed\",\"errcode\":-1}";
			//prt("%d\n", strRet.size());
			sprintf(retbuf + strlen(api_header), "nContent-Length: %d\r\n\r\n%s", (int)strRet.size(), strRet.c_str());
		}
		else {
			prt("getmrcv curkey=%s, querykey=%s, svr=%s\n", mCurSchd0.key.c_str(), m_key, m_m0);
			if (mCurSchd0.key.compare(m_key) == 0) {
				sprintf(retbuf + strlen(api_header), "nContent-Length: %d\r\n\r\n{\"ret\":\"OK\",\"mrcv\":\"%s\"}", 22 + (int)strlen(m_m0), m_m0);
			}
			else {
				sprintf(retbuf + strlen(api_header), "nContent-Length: %d\r\n\r\n{\"ret\":\"FAILED\",\"mrcv\":\"\"}", 26);
			}
		}

		apisvr_write_response(fd, retbuf);
	}
	else if (strncmp(buffer, api_start, strlen(api_start)) == 0 || strncmp(buffer, api_Start, strlen(api_Start)) == 0)
	{
		prt("api_start\n");
		//---- API_START
		apisvr_write_response_ok(fd, api_header, retbuf);		
	}
	else if (strncmp(buffer, api_stop, strlen(api_stop)) == 0 || strncmp(buffer, api_Stop, strlen(api_Stop)) == 0)
	{
		prt("api_stop\n");
		//---- API_STOP
		apisvr_write_response_ok(fd, api_header, retbuf);

		m_newAdv = "";
		m_mtxSchd.lock();
		m_lstSchd.clear();
		m_mtxSchd.unlock();
		mcastsvr_stop(0);
	}
	else if (strncmp(buffer, api_status, strlen(api_status)) == 0 || strncmp(buffer, api_Status, strlen(api_Status)) == 0)
	{
		prt("api_status\n");
		//---- API_STATUS
		apisvr_write_response_ok(fd, api_header, retbuf);
	}
	else if (strncmp(buffer, api_exit, strlen(api_exit)) == 0 || strncmp(buffer, api_Exit, strlen(api_Exit)) == 0)
	{
		prt("api_exit\n");
		//---- API_EXIT
		m_bAppExit = true;
		//---- WRITE RESPONSE
		apisvr_write_response_ok(fd, api_header, retbuf);
	}
	else
	{
		prt("api_unknown\n");

		//---- WRITE RESPONSE
		std::string strRet = "{\"ret\":\"NO\"}";
		sprintf(retbuf + strlen(api_header), "nContent-Length: %d\r\n\r\n%s", (int)strRet.size(), strRet.c_str());
		apisvr_write_response(fd, retbuf);
	}

#ifdef _FORK
	exit(1);
#else
	
#endif
}

void apisvr_response(int fd, const char* json_body)
{
    char response[MAX_RCVBUF];
    int body_len = strlen(json_body);

	// HTTP HEADER
    int header_len = sprintf(response,
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: application/json\r\n"
        "Content-Length: %d\r\n"
        "Connection: close\r\n"
        "\r\n"
        "%s", body_len, json_body);

    //send(fd, response, header_len, 0);
	int wrt = write(fd, response, header_len);
	//prt("written %d\n", wrt);	
}

void apisvr_parse(int fd, char* phdr, char* pctx, int len)
{
	int  ir = 0;
	char value[256] = { 0 };
	const char api_Init[] = "POST /init";
	const char api_init[] = "post /init";
	const char api_Setad[] = "POST /setad";
	const char api_setad[] = "post /setad";
	const char api_Schedule[] = "POST /schedule";
	const char api_schedule[] = "post /schedule";
	const char api_Getmrcv[] = "POST /getmrcv";
	const char api_getmrcv[] = "post /getmrcv";
	const char api_Start[] = "GET /start";
	const char api_start[] = "get /start";
	const char api_Stop[] = "GET /stop";
	const char api_stop[] = "get /stop";
	const char api_Status[] = "GET /status";
	const char api_status[] = "get /status";
	const char api_Exit[] = "GET /exit";
	const char api_exit[] = "get /exit";

	//---- PROCESS ARGUMENTS
	if (strncmp(phdr, api_init, strlen(api_init)) == 0 || strncmp(phdr, api_Init, strlen(api_Init)) == 0)
	{	// API_INIT
		prt("api_init\n");

		ir = parse_value(pctx, "\"rp\":", m_rp);		
		if (ir < 0) { prt("failed to parse value\n"); } else prt("rp=%s\n", m_rp);
		ir = parse_value(pctx, "\"group\":", m_gr);	
		if (ir < 0) { prt("failed to parse value\n"); } else prt("group=%s\n", m_gr);
		ir = parse_value(pctx, "\"mrcv0\":", m_m0);
		m_rtmpRcv0 = m_m0;
		if (ir < 0) { prt("failed to parse value\n"); } else prt("mrcv0=%s\n", m_m0);
		ir = parse_value(pctx, "\"mrcv1\":", m_m1);
		m_rtmpRcv1 = m_m1;
		if (ir < 0) { prt("failed to parse value\n"); } else prt("mrcv1=%s\n", m_m1);
		ir = parse_value(pctx, "\"chport\":", m_ch);
		if (ir < 0) { prt("failed to parse value\n"); } else prt("chport=%s\n", m_ch);
		ir = parse_value(pctx, "\"apiport\":", m_ap);
		if (ir < 0) { prt("failed to parse value\n"); } else prt("apiport=%s\n", m_ap);

		m_newAdv = "";
		m_mtxSchd.lock();
		m_lstSchd.clear();
		m_mtxSchd.unlock();
		mcastsvr_stop(0);

		apisvr_response(fd, "{\"ret\":\"OK\"}");
	}
	else if (strncmp(phdr, api_setad, strlen(api_setad)) == 0 || strncmp(phdr, api_Setad, strlen(api_Setad)) == 0)
	{	//---- API_SETAD	
		m_mtxAdv.lock();
		ir = parse_value(pctx, "\"ad\":", value);
		prt("api_setad [%s]\n", value);
		if (ir < 0) {
			prt("failed to parse value\n");
		}
		else {
			m_newAdv = value;
		}
		m_mtxAdv.unlock();

		apisvr_response(fd, "{\"ret\":\"OK\"}");
	}
	else if (strncmp(phdr, api_schedule, strlen(api_schedule)) == 0 || strncmp(phdr, api_Schedule, strlen(api_Schedule)) == 0)
	{	//---- API_SETSCHEDULE
		prt("api_setschedule\n");

		m_mtxSchd.lock();
		parse_schedule_ex(pctx);
		m_mtxSchd.unlock();

		apisvr_response(fd, "{\"ret\":\"OK\"}");
	}
	else if (strncmp(phdr, api_getmrcv, strlen(api_getmrcv)) == 0 || strncmp(phdr, api_Getmrcv, strlen(api_Getmrcv)) == 0)
	{	//---- API_GETMRCV
		prt("api_getmrcv\n");
		
		ir = parse_value(pctx, "\"key\":", m_key);
		if (ir < 0) { 
			prt("failed to parse value\n");
			apisvr_response(fd, "{\"ret\":\"Failed\",\"errcode\":-1}");
		}
		else {
			prt("getmrcv curkey=%s, querykey=%s, svr=%s\n", mCurSchd0.key.c_str(), m_key, m_m0);
			if (mCurSchd0.key.compare(m_key) == 0) {
				char strRcv[512] = { 0 };
				sprintf(strRcv, "{\"ret\":\"OK\",\"mrcv\":\"%s\"}", m_m0);
				apisvr_response(fd, strRcv);
			}
			else {
				apisvr_response(fd, "{\"ret\":\"Failed\",\"mrcv\":\"\"}");				
			}
		}
	}
	else if (strncmp(phdr, api_start, strlen(api_start)) == 0 || strncmp(phdr, api_Start, strlen(api_Start)) == 0)
	{	//---- API_START
		prt("api_start\n");
		
		apisvr_response(fd, "{\"ret\":\"OK\"}");
	}
	else if (strncmp(phdr, api_stop, strlen(api_stop)) == 0 || strncmp(phdr, api_Stop, strlen(api_Stop)) == 0)
	{	//---- API_STOP
		prt("api_stop\n");
	
		m_newAdv = "";
		m_mtxSchd.lock();
		m_lstSchd.clear();
		m_mtxSchd.unlock();
		mcastsvr_stop(0);

		apisvr_response(fd, "{\"ret\":\"OK\"}");
	}
	else if (strncmp(phdr, api_status, strlen(api_status)) == 0 || strncmp(phdr, api_Status, strlen(api_Status)) == 0)
	{	//---- API_STATUS
		prt("api_status\n");

		apisvr_response(fd, "{\"ret\":\"OK\"}");
	}
	else if (strncmp(phdr, api_exit, strlen(api_exit)) == 0 || strncmp(phdr, api_Exit, strlen(api_Exit)) == 0)
	{	//---- API_EXIT
		prt("api_exit\n");
		
		m_bAppExit = true;

		apisvr_response(fd, "{\"ret\":\"OK\"}");
	}
	else
	{	//---- UNKNOWN
		prt("api_unknown\n");
	
		apisvr_response(fd, "{\"ret\":\"UNKNOWN\"}");
	}
}

void apisvr_proc_ex(int fd, int idx, char* new_data, int new_len)
{
	ClientContext *ctx = &g_client_ctx[idx];

	char api_method[7] = { 0 };
	char api_post[] = "post /";
	char api_get[]  = "get /";

	// RESET BUFFER
	if(new_len >= 6 && ctx->len > 0) {
		for (int i = 0; i<6; i++) {
        	api_method[i] = tolower(new_data[i]);
    	}
		if( strncmp(api_method, api_post, strlen(api_post)) == 0 || 
			strncmp(api_method, api_get,  strlen(api_get) ) == 0 ) {
			// RESET BUFFER
			ctx->len = 0;
			memset(ctx->buf, 0, MAX_RCVBUF);
		}
	}

    // ACCUMULATE DATA TO BUFFER
    if (ctx->len + new_len < MAX_RCVBUF) {
        memcpy(ctx->buf + ctx->len, new_data, new_len);
        ctx->len += new_len;
        ctx->buf[ctx->len] = '\0';
    }

    // CHECK THE ENDO FO HTTP HEADER ( \r\n\r\n )
	char *header_end = strstr(ctx->buf, "\r\n\r\n");
	if (header_end != NULL)
	{
		bool rcv_done = false;
		int header_size = (header_end - ctx->buf) + 4;
		if(header_size>=ctx->len) {
			rcv_done = true;
			// HTTP RESPONSE
			apisvr_response(fd, "{\"ret\":\"OK\"}");
		}
		else {
			char *cl_ptr = strcasestr(ctx->buf, "Content-Length:");
			if (cl_ptr) {
				int body_len = atoi(cl_ptr + 15);
				// CHECK IF ALL BODY DATA IS RECEIVED
				if (ctx->len >= (header_size + body_len)) {
					rcv_done = true;
					char *body_ptr = header_end + 4;
					// PARSE DATA
					apisvr_parse(fd, ctx->buf, body_ptr, body_len);
					//prt("%s\n", header_end);
				}
			}
		}

		if(rcv_done)
		{
			// RESET BUFFER
			ctx->len = 0;
			memset(ctx->buf, 0, MAX_RCVBUF);
		}
    }
	else {
		printf("### header not found!!\n");
	}

	if(ctx->len!=0) {
		prt("api request not completed fd=%d\n", fd);
	}
}

///////////////////////////////////////////////////////////////////////////////
// main
///////////////////////////////////////////////////////////////////////////////
int main(int argc, char** argv)
{
	prt("--------------------------------------\n");
	prt("  MCast v%s\n", VERSION);
	prt("--------------------------------------\n");

	if (argc != 3) {
		prt("  Usage: mcast [API_PORT:7000] [SVR_IP]\n");
		exit(0);
	}

	int  i;
	int  ret;
	int  api_port = 7000;
	char svr_ip[128] = { 0 };

	int fd_listen = -1;
	int fd_accept = -1;
	int fd_client[MAX_CLIENT];
	uint8_t buf_rcv[MAX_RCVBUF];

	socklen_t sock_len;
	struct sockaddr_in svr_addr = { 0 };
	struct sockaddr_in cli_addr = { 0 };
	struct timeval tv_tmout;

	fd_set fd_read;
    FD_ZERO(&fd_read);
    for(i=0; i<MAX_CLIENT; i++) {
        fd_client[i] = -1;
    }
	memset(buf_rcv, 0, MAX_RCVBUF);
	for(i=0; i<MAX_CLIENT; i++) {
		memset(&g_client_ctx[i], 0, sizeof(ClientContext));
	}

	api_port = atoi(argv[1]);
	strcpy(svr_ip, argv[2]);

	prt("api_port=%d, api_ip=%s\n", api_port, svr_ip);

	if(api_port<=0 || api_port>65000) {
		prt("mcast server: invalid port number: %d\n", api_port);
        return -1;
    }

	prt("mcast server: initialize the listen socket\n");
	if ((fd_listen = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		prt("failed to open socket\n");
		return -1;
	}

	int opt = 1;
	if (setsockopt(fd_listen, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0)
	{
		prt("failed to set SO_REUSEADDR\n");
		return -1;
	}
	if (setsockopt(fd_listen, SOL_SOCKET, SO_REUSEPORT, &opt, sizeof(opt)) < 0)
	{
		prt("failed to set SO_REUSEPORT\n");
		return -1;
	}

	memset(&svr_addr, 0, sizeof(struct sockaddr_in));
	svr_addr.sin_family 	 = AF_INET;
	svr_addr.sin_port 		 = htons((uint16_t)api_port);
	svr_addr.sin_addr.s_addr = htonl(INADDR_ANY);

	// PORT 1~1024: needs root permission
	if(bind(fd_listen, (struct sockaddr *)&svr_addr, sizeof(struct sockaddr_in)) < 0) {
		prt("mcast server error: mcast server socket bind\n");
		prt("Err: %s\n", strerror(errno));
    }
	if(listen(fd_listen, MAX_CLIENT) < 0) {
		prt("mcast server error: mcast server listen\n");
    }

#ifdef _EN_SCHEDULE_THREAD
	int ir = pthread_create(&schedule_pthread, NULL, schedule_thread, NULL);
	if (ir) {
		prt("failed to schedule pthread_create\n");
	}
#endif

	prt("started mcast server\n");
		
	while (!m_bAppExit) {

		// SET THE FD_SET BEFORE PASSING IT TO THE SELECT CALL
        FD_ZERO(&fd_read);
        FD_SET(fd_listen, &fd_read);   
        int fd_max = fd_listen;

		for(i=0; i<MAX_CLIENT; i++) {
             if(fd_client[i] > 0) {
                 FD_SET(fd_client[i], &fd_read);
             }
             if(fd_client[i] > fd_max) {
                fd_max = fd_client[i];
             }
        }

		tv_tmout.tv_sec  = 0;
        tv_tmout.tv_usec = 100 * 1000;   // 100 ms(0.1s)

		// SELECT
        ret = select(fd_max+1, &fd_read, NULL, NULL, &tv_tmout);
        if(ret > 0 ) {
			if(FD_ISSET(fd_listen, &fd_read)) { 
                // ACCEPT THE NEW CONNECTION
                socklen_t sock_len = sizeof(struct sockaddr_in);
                fd_accept = accept(fd_listen, (struct sockaddr*)&cli_addr, &sock_len);
                if(fd_accept > 0) {
                    //sock_len = sizeof(struct sockaddr_in);
                    //getpeername(fd_accpet , (struct sockaddr*)&cli_addr , (socklen_t*)&addrlen); 
                    uint8_t ipaddr[32] = {'\0'};
                    memset(ipaddr, 0, 32);
                    inet_ntop(AF_INET, &(cli_addr.sin_addr), (char*)ipaddr, 32);
                    prt("mcast server: socket accepted new connection [fd=%d,peer=%s]\n", fd_accept, (char*)ipaddr);
                    for(i=0; i<MAX_CLIENT; i++) {
                        if (fd_client[i] < 0) {
                            fd_client[i] = fd_accept; 
                            break;
                        }
                    }
                }
                else {
                    prt("mcast server error: socket accept failed [%s]\n", strerror(errno));
                }
                ret--;
                if(ret > 0) {
                    continue;
                }
            }

			for(i=0; i<MAX_CLIENT; i++) {
                if(fd_client[i] > 0) {
                    if(FD_ISSET(fd_client[i], &fd_read)) {
                        // RECEIVE
                        memset(buf_rcv, 0, MAX_RCVBUF);
                        ret = recv(fd_client[i], buf_rcv, MAX_RCVBUF, 0);
                        if (ret > 0) {
							apisvr_proc_ex(fd_client[i], i, (char*)buf_rcv, ret);
                            prt("mcast server: procedure finished [fd=%d,len=%d]\n", fd_client[i], ret);
							int fd_close = fd_client[i];
							close(fd_close);
							FD_CLR(fd_close, &fd_read);
                            fd_client[i] = -1;
                        }
                        // DISCONNECT
                        else if(ret == 0) {
                            prt("mcast server: disconnected [fd=%d]\n", fd_client[i]);
							int fd_close = fd_client[i];					
                            close(fd_client[i]);
							FD_CLR(fd_close, &fd_read);
                            fd_client[i] = -1;
                        }
                        // ERROR
                        else if(ret == -1) {
                            prt("mcast server error: failed recv() [fd=%d,%s]\n", fd_client[i], strerror(errno));
                            close(fd_client[i]);
                            fd_client[i] = -1;
                        }
                    }
                }
            }
		}
	}

	for(i=0; i<MAX_CLIENT; i++) {
        if(fd_client[i] > 0) {
            close(fd_client[i]);
        }
    }
    if(fd_listen > 0) {
        close(fd_listen);
    }

#ifdef _EN_SCHEDULE_THREAD
	pthread_join(schedule_pthread, NULL);
#endif

	prt("exit mcast server\n");
	return 0;
}


